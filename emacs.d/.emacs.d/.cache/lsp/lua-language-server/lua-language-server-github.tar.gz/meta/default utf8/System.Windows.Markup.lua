---@meta

---@source System.dll
---@class System.Windows.Markup.ValueSerializerAttribute: System.Attribute
---@source System.dll
---@field ValueSerializerType System.Type
---@source System.dll
---@field ValueSerializerTypeName string
---@source System.dll
CS.System.Windows.Markup.ValueSerializerAttribute = {}
