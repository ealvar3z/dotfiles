---@meta
resty_upstream_healthcheck = {}
function resty_upstream_healthcheck.status_page() end
resty_upstream_healthcheck._VERSION = "0.05"
function resty_upstream_healthcheck.spawn_checker(opts) end
return resty_upstream_healthcheck
